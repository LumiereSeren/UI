-- White Glass v4 — 与 WINDUI_WhiteGlass_Rewritten.lua 配套。
-- 先把源码覆盖到下面的 GitHub 路径，再执行示例；源码本身不会创建窗口。
-- 支持文件 API 的环境，也可以把这两个文件放在同一工作目录。
-- Roblox Studio：把源码放进 ModuleScript，用 require(ModuleScript) 替换此加载段。
local UI_URL = "https://raw.githubusercontent.com/LumiereSeren/UI/refs/heads/main/WINDUI_WhiteGlass_Rewritten.lua?v=white-glass-4"
local LOCAL_FILE = "WINDUI_WhiteGlass_Rewritten.lua"
local source
if type(isfile) == "function" and type(readfile) == "function" and isfile(LOCAL_FILE) then
    source = readfile(LOCAL_FILE)
else
    source = game:HttpGet(UI_URL)
end
local WindUI = assert(loadstring(source))()
assert(WindUI.BuildVersion == "PY-WhiteGlass-Rewrite-4", "源码版本不匹配：请先替换源码，再运行此示例")

local WHITE = Color3.fromRGB(255, 255, 255)
local glassEnabled, sceneBlur, blurSize = true, true, 28
local strength, roughness, bodyAlpha = 0.9, 0.8, 0.72
local mistEnabled, mistOpacity, mistSpread = true, 0.34, 1

local Window = WindUI:CreateWindow({
    Title = "PY Hub",
    Author = "White Glass",
    Folder = "PYHub_WhiteGlass_v4",
    Theme = "WhiteGlass",
    ToggleKey = Enum.KeyCode.RightControl,
    Transparent = true,
    Resizable = false,
    ScrollBarEnabled = true,
    TopbarSearchEnabled = true,
    TopbarSearchWidth = 145,
    TopbarSearchPlaceholder = "搜索功能...",
    SearchHotkey = Enum.KeyCode.K,
    SearchRequiresControl = true,
    -- 不设置 Size：默认 580 × 460，小屏只自动缩小，不放大。
    -- 不提供手动缩放控件；保留原版 SetUIScale API 供旧脚本兼容。
    Beauty = {
        FrostedGlass = glassEnabled,
        BodyTransparency = bodyAlpha,
        GlassStrength = strength,
        GlassRoughness = roughness,
        GlassTexture = true,
        GlobalBlur = sceneBlur, -- 原生 BlurEffect 会模糊整个 3D 视野，可在页面内关闭。
        BlurSize = blurSize,
        AccentColor = WHITE,
        CloudMist = mistEnabled,
        MistOpacity = mistOpacity,
        MistSpread = mistSpread,
        MotionEnabled = true,
        HoverMotion = true,
    },
    OpenButton = {Title = "PY Hub", OnlyIcon = false, Draggable = false},
})

Window:OnOpen(function() print("[PY Hub] 打开") end)
Window:OnClose(function() print("[PY Hub] 收入顶部灵动岛") end)
Window:OnDestroy(function() print("[PY Hub] 已销毁") end)
WindUI:SetNotificationLower(true)

local function notify(title, content)
    return WindUI:Notify({Title = title, Content = content, Duration = 4})
end
local function applyGlass()
    Window:SetFrostedGlass(glassEnabled, {
        GlobalBlur = glassEnabled and sceneBlur,
        BlurSize = blurSize,
        BodyTransparency = bodyAlpha,
        GlassStrength = strength,
        GlassRoughness = roughness,
    })
end
local function applyMist()
    Window:SetCloudMist(mistEnabled, {Opacity = mistOpacity, Spread = mistSpread})
end

-- 原版调用：CreateWindow -> Tab -> 控件配置表。
local Home = Window:Tab({Title = "主页", Icon = "house"})
Home:Paragraph({Title = "White Glass", Desc = "白色、通透、柔和。右 Ctrl 显示或隐藏，Ctrl + K 搜索。"})
Home:Button({Title = "显示通知", Icon = "bell", Callback = function()
    notify("欢迎回来", "新的白色玻璃窗口已加载。")
end})
Home:DebouncedButton("防止连续点击", 2, function()
    notify("已触发", "两秒内只响应一次。")
end, {Desc = "保留之前的简写接口"})
local Feature = Home:Toggle({Title = "启用测试功能", Value = false, Flag = "Feature", Callback = function(value)
    print("Feature:", value)
end})
local Power = Home:Slider({Title = "功能强度", Step = 1, Value = {Min = 0, Max = 100, Default = 50}, Flag = "Power", Callback = function(value)
    print("Power:", value)
end})
Home:Dropdown({Title = "运行模式", Values = {"普通", "轻量", "安静"}, Value = "普通", Flag = "Mode", Callback = function(value)
    print("Mode:", value)
end})
Home:Input({Title = "备注", Value = "", Placeholder = "输入内容...", Flag = "Note", Callback = function(value)
    print("Note:", value)
end})
Home:Keybind({Title = "通知快捷键", Value = "F", CanChange = true, Flag = "Shortcut", Callback = function(key)
    notify("快捷键", "触发 " .. key)
end})

local Glass = Window:Tab({Title = "玻璃与云雾", Icon = "sparkles"})
Glass:Toggle({Title = "毛玻璃材质", Value = glassEnabled, Flag = "Glass", Callback = function(value)
    glassEnabled = value; applyGlass()
end})
Glass:Slider({Title = "玻璃层次", Step = 1, Value = {Min = 0, Max = 100, Default = strength * 100}, Flag = "Strength", Callback = function(value)
    strength = value / 100; Window:SetGlassStrength(strength)
end})
Glass:Slider({Title = "表面细腻度", Step = 1, Value = {Min = 0, Max = 100, Default = roughness * 100}, Flag = "Roughness", Callback = function(value)
    roughness = value / 100; Window:SetGlassRoughness(roughness)
end})
Glass:Slider({Title = "主体透明度", Step = 1, Value = {Min = 35, Max = 82, Default = bodyAlpha * 100}, Flag = "BodyAlpha", Callback = function(value)
    bodyAlpha = value / 100; applyGlass()
end})
Glass:Toggle({Title = "背景场景模糊", Desc = "影响整个 3D 视野，最小化时暂停", Value = sceneBlur, Flag = "SceneBlur", Callback = function(value)
    sceneBlur = value; applyGlass()
end})
Glass:Slider({Title = "场景模糊强度", Step = 1, Value = {Min = 0, Max = 56, Default = blurSize}, Flag = "BlurSize", Callback = function(value)
    blurSize = value; applyGlass()
end})
Glass:Toggle({Title = "窗口周围云雾", Value = mistEnabled, Flag = "Mist", Callback = function(value)
    mistEnabled = value; applyMist()
end})
Glass:Slider({Title = "云雾浓度", Step = 1, Value = {Min = 0, Max = 60, Default = mistOpacity * 100}, Flag = "MistOpacity", Callback = function(value)
    mistOpacity = value / 100; applyMist()
end})
Glass:Slider({Title = "云雾范围", Step = 1, Value = {Min = 65, Max = 135, Default = mistSpread * 100}, Flag = "MistSpread", Callback = function(value)
    mistSpread = value / 100; applyMist()
end})
Glass:Toggle({Title = "轻柔过渡动画", Value = true, Flag = "Motion", Callback = function(value)
    Window:SetMotionEnabled(value)
end})
Glass:Toggle({Title = "悬浮反馈", Value = true, Flag = "Hover", Callback = function(value)
    Window:SetHoverMotion(value)
end})
Glass:Button({Title = "查看玻璃状态", Callback = function()
    local state = Window:GetGlassState()
    notify("玻璃状态", string.format("材质：%s\n场景模糊：%s，强度 %d",
        state.TextureBackend == "EditableImage" and "细腻纹理" or "渐变材质",
        state.SceneBlurEnabled and "开启" or "关闭", state.SceneBlurSize))
    if state.TextureFallbackReason then print("纹理未启用：", state.TextureFallbackReason) end
end})

local Controls = Window:Tab({Title = "更多控件", Icon = "sliders-horizontal"})
local Choices = Controls:Dropdown({
    Title = "多选标签", Values = {"玻璃", "云雾", "白色", "灵动岛"}, Value = {"白色"},
    Multi = true, AllowNone = true, SearchBarEnabled = true, Flag = "Tags",
    Callback = function(values) print("Tags:", table.concat(values, ", ")) end,
})
Controls:Button({Title = "更新并选中标签", Callback = function()
    Choices:Refresh({"玻璃", "云雾", "白色", "灵动岛", "轻量"})
    Choices:Select({"白色", "轻量"})
end})
Controls:Toggle({Title = "复选框示例", Type = "Checkbox", Value = true, Flag = "Checkbox"})
Controls:Colorpicker({Title = "自定义强调色", Default = WHITE, Transparency = 0, Flag = "Accent", Callback = function(shade)
    Window:SetAccentColor(shade)
end})
Controls:Input({Title = "多行输入", Type = "Textarea", Value = "第一行\n第二行", Placeholder = "写一些文字...", Flag = "Multiline"})
local Fold = Controls:Section({Title = "折叠分组", Icon = "folder", Opened = true, Box = true})
Fold:Toggle({Title = "分组内开关", Value = false, Flag = "GroupToggle"})
Fold:Button({Title = "分组内按钮", Callback = function() notify("分组", "支持搜索、配置与统一锁定。") end})
local Buttons = Fold:Group()
Buttons:Button({Title = "开启测试", Callback = function() Feature:Set(true) end})
Buttons:Button({Title = "关闭测试", Callback = function() Feature:Set(false) end})
local Code = Controls:Code({Title = "调用示例", Code = 'local tab = Window:Tab({Title = "我的页面"})\ntab:Button({Title = "按钮", Callback = function()\n    print("Hello")\nend})'})
Controls:Button({Title = "更新代码块", Callback = function() Code:SetCode('print("White Glass v4")') end})
Controls:Divider()
Controls:Space(1)
-- 图片控件仍是原版 API。需要时填写已发布的图片资产 ID；默认不添加背景图。
-- Controls:Image({Image = "rbxassetid://你的图片ID", AspectRatio = "16:9", Radius = 12})

local Appearance = Window:Tab({Title = "外观与搜索", Icon = "palette"})
local names = {"WhiteGlass"}
for name in pairs(WindUI:GetThemes()) do if name ~= "WhiteGlass" then names[#names + 1] = name end end
table.sort(names)
Appearance:Dropdown({Title = "主题", Values = names, Value = "WhiteGlass", SearchBarEnabled = true, Callback = function(name)
    WindUI:SetTheme(name)
end})
Appearance:Button({Title = "恢复全白外观", Callback = function()
    WindUI:SetTheme("WhiteGlass"); Window:SetAccentColor(WHITE); applyGlass(); applyMist()
end})
Appearance:Toggle({Title = "显示顶部搜索", Value = true, Callback = function(value) Window:SetSearchVisible(value) end})
Appearance:Toggle({Title = "显示顶部时钟", Value = false, Callback = function(value) Window:SetClockVisible(value) end})
Appearance:Button({Title = "搜索玻璃设置", Callback = function() Window:Search("玻璃") end})
Appearance:Button({Title = "清除搜索", Callback = function() Window:Search("") end})
Appearance:Button({Title = "播放柔光掠过", Callback = function() Window:Pulse() end})

local ConfigPage = Window:Tab({Title = "配置与窗口", Icon = "settings"})
-- 原版 ConfigManager；带 Flag 的控件自动注册。
-- 有文件 API 时保存为 JSON；无文件 API 时只保存在本次运行内。
local Config = Window.ConfigManager:Config("Default")
ConfigPage:Toggle({Title = "下次自动加载配置", Value = Config.AutoLoad, Callback = function(value)
    Config:SetAutoLoad(value)
end})
ConfigPage:Button({Title = "保存配置", Callback = function()
    Config:Set("description", "PY Hub White Glass")
    local result, storage = Config:Save()
    if not result then notify("保存失败", tostring(storage)); return end
    notify("已保存", storage == "File" and "配置已保存到文件。" or "当前环境只支持本次运行内保存。")
end})
ConfigPage:Button({Title = "加载配置", Callback = function()
    local result, err = Config:Load()
    notify(result and "已加载" or "加载失败", result and "已恢复带 Flag 的控件。" or tostring(err))
end})
ConfigPage:Button({Title = "确认对话框", Callback = function()
    Window:Dialog({Title = "恢复功能强度？", Content = "将主页滑块恢复到 50。", Buttons = {
        {Title = "取消"}, {Title = "恢复", Variant = "Primary", Callback = function() Power:Set(50) end},
    }}):Open()
end})
ConfigPage:Input({Title = "窗口标题", Value = "PY Hub", Callback = function(value) Window:SetTitle(value) end})
ConfigPage:Button({Title = "锁定主页控件", Callback = function() Home:LockAll(); notify("主页已锁定", "在此页点击解锁即可恢复。") end})
ConfigPage:Button({Title = "解锁主页控件", Callback = function() Home:UnlockAll() end})
ConfigPage:Button({Title = "窗口居中", Callback = function() Window:SetToTheCenter() end})
ConfigPage:Button({Title = "最小化到灵动岛", Callback = function() Window:Close() end})
ConfigPage:Button({Title = "销毁窗口", Callback = function()
    Window:Confirm("销毁窗口", "重新打开需要再次运行示例。", function() Window:Destroy() end)
end})

-- 之前的简写风格也保留：
-- local Page = Window:Page({Title = "简写页面"})
-- Page:Button("按钮", function() end, {Desc = "说明"})
-- Page:Toggle("开关", false, function(value) end)
-- Page:Slider("强度", 0, 100, 50, function(value) end)
-- Page:Dropdown("模式", {"A", "B"}, "A", function(value) end)
-- Page:Input("输入", "", function(value) end)
-- Page:Keybind("快捷键", "F", function(key) end)

Home:Select()
return Window
